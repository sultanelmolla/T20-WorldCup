T20 world cup cricket data analytics

Tools used
1.python
2.pandas
3.power bi

key points

1.created a powerbi report to identify top 11 players for a T20 cricket team by collecting data,cleaning and transforming the data with pandas,and evaluating various players performance metrics.
2.used the resulting powerbi dashboard to select players for various categories(openers,middle order/anchors,finishers,all-rounders,specialist fast bowlers) and ultimately choose the top 11 players to play in the match.
3.Selected team using the powerbi dashboard has 90% chances to win the game.